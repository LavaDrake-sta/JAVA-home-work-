package game.enums;

public enum State_status {
        ACTIVE, INJURED, DISABLED, COMPLETED

}
