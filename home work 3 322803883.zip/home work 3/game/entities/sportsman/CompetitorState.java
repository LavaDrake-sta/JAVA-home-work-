package game.entities.sportsman;

import gui.ArenaPanel;

public interface CompetitorState {
    void handleState(WinterSportsman sportsman, ArenaPanel arenaPanel);
}
