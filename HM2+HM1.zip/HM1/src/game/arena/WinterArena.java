package game.arena;

import game.entities.Entity;
import game.entities.IMobileEntity;
import game.enums.League;
import game.enums.SnowSurface;
import game.enums.WeatherCondition;

public class WinterArena implements IArena{
    private double length;
    private SnowSurface surface;
    private WeatherCondition weatherCondition;

    public WinterArena(double length,SnowSurface surface,WeatherCondition weatherCondition){
        this.length=length;
        this.surface=surface;
        this.weatherCondition=weatherCondition;
    }

    @Override
    public double getFriction() {
        return surface.friction;
    }

    public double getLength() {
        return length;
    }

    public SnowSurface getSurface() {
        return surface;
    }

    public WeatherCondition getWeatherCondition() {
        return weatherCondition;
    }

    public void setLength(double length) {

        this.length = length;
    }

    public void setSurface(SnowSurface surface) {
        this.surface = surface;
    }

    public void setWeatherCondition(WeatherCondition weatherCondition) {
        this.weatherCondition = weatherCondition;
    }

    @Override
    public boolean isFinished(IMobileEntity Me) {
        if (((Entity)Me).getLocation().get_x()>length){
            return true;
        }
        return false;
    }

    public boolean equals(WinterArena obj){
        boolean ans=false;
        if(this.length== obj.length && this.surface==obj.surface && this.weatherCondition == obj.weatherCondition){
            ans=true;
        }
        return  ans;
    }

    @Override
    public String toString() {
        return "WinterArena{" +
                "weatherCondition=" + this.weatherCondition +
                ", league=" + this.length +
                ", surface=" + this.surface +
                '}';
    }
}
