package game.enums;

/**
 * Created by itzhak on 24-Mar-19.
 */
public enum Discipline {
    SLALOM,GIANT_SLALOM,DOWNHILL,FREESTYLE
}
