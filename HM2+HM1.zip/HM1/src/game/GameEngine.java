package game;

import game.Competition.Competition;
import game.Competition.Competitor;

public class GameEngine {
   private static GameEngine instance;
   private static int step = 0;

   private GameEngine() {}

   public static synchronized GameEngine getInstance() {
      if (instance == null) {
         instance = new GameEngine();
      }
      return instance;
   }

   public void startRace(Competition comp) {
      if (comp == null) {
         throw new IllegalArgumentException("Competition cannot be null");
      }

      for (Competitor competitor : comp.getActiveCompetitors()) {
         if (competitor instanceof Runnable) {
            Thread competitorThread = new Thread((Runnable) competitor);
            competitorThread.start();
         } else {
            throw new IllegalArgumentException("Competitor must implement Runnable");
         }
      }

      while (comp.hasActiveCompetitors()) {
         try {
            comp.playTurn();
            Thread.sleep(30);  // Update display every 30 ms
         } catch (InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();  // Restore interrupted status
         }
         step++;
      }

      printResult(comp);
   }

   public void printResult(Competition comp) {
      System.out.println("Race finished in " + step + " steps\nRace results:");
      if (comp != null) {
         System.out.println(comp.printWinners());
      }
   }
}
