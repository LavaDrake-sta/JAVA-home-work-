package game.Competition;

import game.entities.IMobileEntity;
import utilities.Point;

public interface Competitor extends IMobileEntity {
    void initRace();
    void move(double friction);
    Point getLocation();
    void setFriction(Double friction);
   String getName();
   double getSpeed();
    double getMaxSpeed();
    void setFinished(Boolean finished);
    boolean hasFinished();
}
