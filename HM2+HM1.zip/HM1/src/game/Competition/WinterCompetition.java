package game.Competition;

import game.arena.WinterArena;
import game.entities.sportsman.WinterSportsman;
import game.enums.Discipline;
import game.enums.Gender;
import game.enums.League;

public class WinterCompetition extends Competition{
    private Discipline discipline;
    private League league;
    private Gender gender;

    public WinterCompetition(WinterArena arena, int maxCompetitors,Discipline discipline,League league,Gender gender){
        super(arena,maxCompetitors);
        this.discipline = discipline;
        this.league=league;
        this.gender=gender;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public Gender getGender() {
        return gender;
    }

    public League getLeague() {
        return league;
    }


    public void setDiscipline(Discipline discipline) {
        if(this.discipline != null) {
            this.discipline = discipline;
        }
        else{
            throw new IllegalArgumentException("the Discipline you enter are not from this class ");
        }
    }

    public void setGender(Gender gender) {
        if (this.gender != null) {
            this.gender = gender;
        }
        else{
            throw new IllegalArgumentException("the Discipline you enter are not from this class ");
        }

    }

    public void setLeague(League league) {
        if(this.league != null) {
            this.league = league;
        }
        else{
            throw new IllegalArgumentException("the Discipline you enter are not from this class ");
        }
    }
    @Override
    public boolean isValidCompetitor(Competitor competitor){
        if (competitor instanceof WinterSportsman){
            if(this.getLeague().isInLeague(((WinterSportsman) competitor).getage())){
                if(this.getGender() == ((WinterSportsman)competitor).getGender()){
                    return true;

                }
                return false;
            }
            return false;
        }
        return false;
    }

    public boolean equals(WinterCompetition obj){
        boolean ans=false;
        if (this.league==obj.league&&this.discipline==obj.discipline && this.gender==obj.gender){
            ans=true;
        }
        return ans;

    }
    @Override
    public String toString() {
        return "WinterCompetition{" +
                "discipline=" + discipline +
                ", league=" + league +
                ", gender=" + gender +
                '}';
    }
}
