package game.Competition;

import game.arena.WinterArena;
import game.entities.sportsman.WinterSportsman;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

public abstract class Competition implements PropertyChangeListener {
    private WinterArena arena;
    private int maxCompetitors;
    private ArrayList<Competitor> activeCompetitors;
    private ArrayList<Competitor> finishedCompetitors;

    public Competition(WinterArena arena, int maxCompetitors) {
        if (arena == null) {
            throw new IllegalArgumentException("Arena cannot be null");
        }
        if (maxCompetitors <= 0) {
            throw new IllegalArgumentException("maxCompetitors must be positive");
        }
        this.arena = arena;
        this.maxCompetitors = maxCompetitors;
        this.activeCompetitors = new ArrayList<>();
        this.finishedCompetitors = new ArrayList<>();
    }

    public ArrayList<Competitor> getFinishedCompetitors() {
        return finishedCompetitors;
    }

    public ArrayList<Competitor> getActiveCompetitors() {
        return activeCompetitors;
    }

    public int getMaxCompetitors() {
        return maxCompetitors;
    }

    public void setArena(WinterArena arena) {
        this.arena = arena;
    }

    public void setActiveCompetitors(ArrayList<Competitor> activeCompetitors) {
        this.activeCompetitors = activeCompetitors;
    }

    public void setFinishedCompetitors(ArrayList<Competitor> finishedCompetitors) {
        this.finishedCompetitors = finishedCompetitors;
    }

    public void setMaxCompetitors(int maxCompetitors) {
        this.maxCompetitors = maxCompetitors;
    }

    public WinterArena getArena() {
        return arena;
    }

    public abstract boolean isValidCompetitor(Competitor competitor);

    public void addCompetitor(Competitor competitor) {
        if (activeCompetitors.size() >= maxCompetitors) {
            throw new IllegalStateException("Competition is full");
        }
        if (!isValidCompetitor(competitor)) {
            throw new IllegalArgumentException("Competitor is not valid for this competition");
        }
        activeCompetitors.add(competitor);
        competitor.setFriction(arena.getFriction());
        competitor.initRace();
        if (competitor instanceof WinterSportsman) {
            ((WinterSportsman) competitor).addPropertyChangeListener(this);
            new Thread((WinterSportsman) competitor).start(); // Start the competitor as a thread
        }
    }


    @Override
    public synchronized  void propertyChange(PropertyChangeEvent evt) {
        if ("finished".equals(evt.getPropertyName())) {
            WinterSportsman sportsman = (WinterSportsman) evt.getSource();
            if (activeCompetitors.remove(sportsman)) {
                finishedCompetitors.add(sportsman);
                sportsman.removePropertyChangeListener(this);
            }
        }
    }

    public void playTurn() {
        ArrayList<Competitor> tempActiveCompetitors = new ArrayList<>(activeCompetitors);
        for (Competitor competitor : tempActiveCompetitors) {
            competitor.move(arena.getFriction());
            if (arena.isFinished(competitor)) {
                competitor.setFinished(true);
                activeCompetitors.remove(competitor);
                finishedCompetitors.add(competitor);
                if (competitor instanceof WinterSportsman) {
                    ((WinterSportsman) competitor).removePropertyChangeListener(this);
                }
            }
        }
        System.out.println("Active competitors: " + activeCompetitors.size());
        System.out.println("Finished competitors: " + finishedCompetitors.size());
    }

    public String printWinners() {
        int i = 1;
        StringBuilder winners = new StringBuilder();
        for (Competitor competitor : finishedCompetitors) {
            if (competitor instanceof WinterSportsman) {
                winners.append(i).append(". ").append(((WinterSportsman) competitor).getName()).append("\n");
                i++;
            }
        }
        return winners.toString();
    }

    public boolean hasActiveCompetitors() {
        return !activeCompetitors.isEmpty();
    }

    @Override
    public String toString() {
        return "Competition{" +
                "arena=" + arena +
                "maxCompetitors=" + maxCompetitors +
                ", activeCompetitors=" + activeCompetitors +
                ", finishedCompetitors=" + finishedCompetitors +
                '}';
    }
}
