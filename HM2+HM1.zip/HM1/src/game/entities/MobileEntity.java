package game.entities;
import utilities.Point;


public  abstract class MobileEntity extends Entity implements IMobileEntity {
    private Double maxSpeed;
    private Double acceleration;
    private Double speed;

    public MobileEntity(double maxSpeed, double acceleration) {
        super(new Point(0, 0)); // Assuming default location for mobile entity
        this.maxSpeed = maxSpeed;
        this.acceleration = acceleration;
        this.speed = 0.0;
    }
    public double getMaxSpeed() {
        return maxSpeed;
    }
    public void setMaxSpeed(double maxSpeed) {
        this.maxSpeed = maxSpeed;
    }
    public double getAcceleration() {
        return acceleration;
    }
    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }
    public double getSpeed() {
        return speed;
    }
    public void setSpeed(double speed) {
        this.speed = speed;
    }
    @Override
    public void move(double friction){
        speed += acceleration*friction;
        if (speed >= maxSpeed){
            speed= maxSpeed;
        }
        super.getLocation().set_x(super.getLocation().get_x()+speed);

    }
    @Override
    public Point getLocation(){
        return super.getLocation();
    }

    @Override
    public String toString() {
        return "MobileEntity{" +
                "maxSpeed=" + maxSpeed +
                ", acceleration=" + acceleration +
                ", speed=" + speed +
                ", location=" + getLocation() +
                '}';
    }
}
