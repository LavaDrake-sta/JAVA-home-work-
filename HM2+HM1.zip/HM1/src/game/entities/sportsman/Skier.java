package game.entities.sportsman;

import game.enums.Discipline;
import game.enums.Gender;
import game.enums.League;

public class Skier extends WinterSportsman{
    public Skier(Discipline discipline, League league, String name, Double age, Gender gender, double maxspeed, double acceleration){
        super(discipline, league,  name,  age,  gender,  maxspeed,  acceleration);
    }
}
