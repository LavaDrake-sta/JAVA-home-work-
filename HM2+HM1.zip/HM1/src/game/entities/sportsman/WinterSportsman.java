package game.entities.sportsman;

import game.Competition.Competitor;
import game.enums.Discipline;
import game.enums.Gender;
import game.enums.League;
import utilities.Point;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public abstract class WinterSportsman extends Sportsman implements Competitor, Runnable {
    private Discipline discipline;
    private League league;
    private Boolean finished;
    private Double friction;
    private PropertyChangeSupport support;

    public WinterSportsman(Discipline discipline, League league, String name, Double age, Gender gender, double maxspeed, double acceleration) {
        super(name, age, gender, maxspeed, acceleration);
        this.discipline = discipline;
        this.league = league;
        this.finished = false;
        this.support = new PropertyChangeSupport(this);
    }

    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    public void setLeague(League league) {
        this.league = league;
    }

    public Discipline getDiscipline() {
        return this.discipline;
    }

    public League getLeague() {
        return this.league;
    }

    @Override
    public void setFriction(Double friction) {
        this.friction = friction;
    }

    @Override
    public void setFinished(Boolean finished) {
        Boolean oldFinished = this.finished;
        this.finished = finished;
        support.firePropertyChange("finished", oldFinished, finished);
    }

    @Override
    public boolean hasFinished() {
        return finished;
    }

    @Override
    public Gender getGender() {
        return super.getGender();
    }

    @Override
    public Double getage() {
        return super.getage();
    }

    @Override
    public double getAcceleration() {
        return super.getAcceleration() + League.calcAccelerationBonus(getage());
    }

    @Override
    public void initRace() {
        Point temp = this.getLocation();
        if (temp == null) {
            temp = new Point();
            this.setLocation(temp);
        }
    }

    @Override
    public void move(double friction) {
        double oldX = getLocation().get_x();
        this.setSpeed(this.getSpeed() + this.getAcceleration() * friction);
        if (this.getSpeed() >= this.getMaxSpeed()) {
            this.setSpeed(this.getMaxSpeed());
        }
        double newX = oldX + this.getSpeed();
        super.getLocation().set_x(newX);
        support.firePropertyChange("location", oldX, newX);
    }

    @Override
    public Point getLocation() {
        return super.getLocation();
    }

    @Override
    public void run() {
        Thread.currentThread().setPriority(Thread.NORM_PRIORITY);
        System.out.println(this.getName() + " starting run method.");
        while (!hasFinished()) {
            move(friction);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(this.getName() + " finished.");
        support.firePropertyChange("finished", false, true);
    }


    public void addPropertyChangeListener(PropertyChangeListener listener) {
        support.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        support.removePropertyChangeListener(listener);
    }

    @Override
    public String toString() {
        return "WinterSportsman{" +
                "name='" + this.getName() + '\'' +
                ", age=" + this.getage() +
                ", gender=" + this.getGender() +
                ", discipline=" + this.getDiscipline() +
                ", location=" + getLocation() +
                ", maxSpeed=" + getMaxSpeed() +
                ", acceleration=" + getAcceleration() +
                ", speed=" + getSpeed() +
                '}';
    }
}
