package game.entities.sportsman;

import game.entities.MobileEntity;
import game.enums.Gender;

public abstract class Sportsman extends MobileEntity {
    private String name;
    private Double age;
    private Gender gender;
    public Sportsman(String name,Double age,Gender gender,double maxspeed,double acceleration){
        super(maxspeed,acceleration);
        this.name=name;
        this.age=age;
        this.gender=gender;
    }
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name=name;
    }
    public Double getage(){
        return this.age;
    }
    public void setAge(Double age){
        this.age=age;
    }

    public Gender getGender(){

        return this.gender;
    }
    public void setGender(Gender gender){
        this.gender=gender;
    }


}
