package utilities;

public class Point {
    private double x,y;
    public Point(double x,double y) {
        ValidationUtils.assertInRange(x, 0, 1000000);
        this.x=x;
        ValidationUtils.assertInRange(y, 0, 800);
        this.y=y;
    }
    public Point(Point other) {
        this.x=other.x;
        this.y=other.y;

    }
    public Point() {
        this.x=0;
        this.y=0;
    }

    public double get_x() {
        return this.x;
    }
    public double get_y() {
        return this.y;
    }
    public void set_x(double x) {
        ValidationUtils.assertInRange(x, 0, 1000000);
        this.x =x;
    }
    public void set_y(double y) {
        ValidationUtils.assertInRange(y, 0, 800);
        this.y =y;
    }
    @Override
    public String toString() {
        String temp =("the point is x:" +this.x +"the point y:"+ this.y);
        return temp;
    }

    public boolean equals(Point other) {
        boolean ans= false;
        if (other instanceof Point) {
            ans= (this.x ==((Point)other).x && this.y == ((Point)other).y);
        }
        return ans;
    }
}
