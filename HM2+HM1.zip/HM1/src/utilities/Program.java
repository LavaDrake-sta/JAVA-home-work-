/**
 *
 */
package utilities;

import game.GameEngine;
import game.arena.WinterArena;
import game.Competition.Competition;
import game.Competition.SkiCompetition;
import game.Competition.WinterCompetition;
import game.entities.sportsman.Skier;
import game.entities.sportsman.Snowboarder;
import game.entities.sportsman.WinterSportsman;
import game.enums.*;

import java.lang.reflect.Constructor;


/**
 * @author Itzhak Eretz Kdosha
 * Main class(run demo)
 */
public class Program {

	public static void main(String[] args) {
		WinterArena arena = new WinterArena(1000,SnowSurface.CRUD,WeatherCondition.SUNNY);
		Skier skier1 = new Skier(Discipline.DOWNHILL,League.ADULT,"sk1",23.0, Gender.MALE, 60, 4.5);
		Skier skier2 = new Skier(Discipline.DOWNHILL,League.ADULT,"sk2",25.0, Gender.MALE,50,5.0);
		Skier skier3 = new Skier(Discipline.GIANT_SLALOM,League.ADULT,"sk3",23.0, Gender.FEMALE,45,3.5);
		Snowboarder jonsnowboarder = new Snowboarder(Discipline.DOWNHILL,League.ADULT,"jon",25.0, Gender.FEMALE, 50,6.5);
		Skier skier4 = new Skier(Discipline.DOWNHILL,League.ADULT,"sk4",29.0, Gender.MALE, 75,4.5);
		Skier skier5 = new Skier(Discipline.DOWNHILL,League.ADULT,"sk5",29.0, Gender.MALE, 80,3.3 );



		SkiCompetition competition = new SkiCompetition(arena,3,Discipline.DOWNHILL, League.ADULT,Gender.MALE);
		competition.addCompetitor(skier1);
		competition.addCompetitor(skier2);
		System.out.println("--------------- Exception example 1 ---------------");
		try{
			competition.addCompetitor(skier3);
		}
		catch (IllegalArgumentException e){
			e.printStackTrace(System.out);
		}
		System.out.println("--------------- Exception example 2 ---------------");
		try{
			competition.addCompetitor(jonsnowboarder);
		}
		catch (IllegalArgumentException e){
			e.printStackTrace(System.out);
		}
		System.out.println("--------------- Exception example 3 ---------------");
		competition.addCompetitor(skier4);
		try{
			competition.addCompetitor(skier5);
		}
		catch (IllegalStateException e){
			e.printStackTrace(System.out);
		}
		System.out.println("--------------- COMPETE ---------------");
		GameEngine.getInstance().startRace(competition);
	}

}
