package GUI;

import game.Competition.Competitor;
import game.Competition.WinterCompetition;
import game.entities.sportsman.Skier;
import game.entities.sportsman.Snowboarder;
import game.entities.sportsman.Sportsman;
import game.entities.sportsman.WinterSportsman;
import game.enums.*;
import game.arena.WinterArena;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.atomic.AtomicInteger;

public class competition extends JFrame {
    private JPanel mainPanel;
    private JPanel LeftPanel;
    private JPanel rightPanel;
    private JComboBox<String> competitionTypeComboBox;
    private JComboBox<String> weatherConditionComboBox;
    private JComboBox<String> snowsurfacebox;
    private JComboBox<String> disciplinebox;
    private JComboBox<String> leaguebox;
    private JComboBox<String> genderbox;
    private JTextField maxCompetitiorsnumber;
    private JTextField arenaLengthField;
    private JTextField competitorNameField;
    private JTextField competitorAgeField;
    private JTextField competitorMaxSpeedField;
    private JTextField competitorAccelerationField;

    private JButton createcompetition;
    private JButton buildArenaButton;
    private JButton addCompetitorButton;
    private JButton startCompetitionButton;
    private JButton showInfoButton;



    private WinterArena arena;
    private Skier competitor_ski;
    private Snowboarder competitor_snow;
    private WinterCompetition comp;
    private Gender Compgender;
    private ArrayList<WinterSportsman> compTabel;
    private ImageIcon icon;
    private String CompetitorimagePath;
    private Map<Sportsman, Integer> competitorXPositions = new HashMap<>();
    private Timer timer;
    private boolean competitionStarted;
    private boolean competitionFinished;



    public competition() {
        setTitle("Competition Simulator");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        rightPanel = new JPanel();
        rightPanel.setPreferredSize(new Dimension(220, getHeight())); // גודל משוער לפאנל הימני
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        LeftPanel = new JPanel();
        LeftPanel.setLayout(new BorderLayout());
        LeftPanel.setBorder(BorderFactory.createTitledBorder("Arena"));

        //===============================================

        // Top Panel for Configuration
        JPanel configPanel = new JPanel();
        configPanel.setLayout(new BoxLayout(configPanel, BoxLayout.Y_AXIS));
        configPanel.setBorder(BorderFactory.createTitledBorder("Configure Arena"));

        weatherConditionComboBox = new JComboBox<>(new String[]{"SUNNY", "CLOUDY", "STORMY"});
        snowsurfacebox = new JComboBox<>(new String[]{"POWDER", "CRUD", "ICE"});
        arenaLengthField = new JTextField("700 MIN/900 MAX");
        buildArenaButton = new JButton("Build Arena");

        configPanel.add(new JLabel("Arena Length:"));
        configPanel.add(arenaLengthField);
        configPanel.add(new JLabel("Snow surface:"));
        configPanel.add(snowsurfacebox);
        configPanel.add(new JLabel("Weather Condition:"));
        configPanel.add(weatherConditionComboBox);
        configPanel.add(buildArenaButton);

        //===============================================

        // Middle Panel for Creating Competition
        JPanel createCompetitionPanel = new JPanel();
        createCompetitionPanel.setLayout(new BoxLayout(createCompetitionPanel, BoxLayout.Y_AXIS));
        createCompetitionPanel.setBorder(BorderFactory.createTitledBorder("Create Competition"));

        competitionTypeComboBox = new JComboBox<>(new String[]{"Ski", "Snowboard"});
        maxCompetitiorsnumber = new JTextField("10");
        disciplinebox = new JComboBox<>(new String[]{"SLALOM", "GIANT_SLALOM", "DOWNHILL", "FREESTYLE"});
        leaguebox = new JComboBox<>(new String[]{"JUNIOR", "ADULT", "SENIOR"});
        genderbox = new JComboBox<>(new String[]{"FEMALE", "MALE"});
        createcompetition = new JButton("Create competition");

        createCompetitionPanel.add(new JLabel("Competition Type:"));
        createCompetitionPanel.add(competitionTypeComboBox);
        createCompetitionPanel.add(new JLabel("Max competitors number:"));
        createCompetitionPanel.add(maxCompetitiorsnumber);
        createCompetitionPanel.add(new JLabel("Discipline:"));
        createCompetitionPanel.add(disciplinebox);
        createCompetitionPanel.add(new JLabel("League:"));
        createCompetitionPanel.add(leaguebox);
        createCompetitionPanel.add(new JLabel("Gender:"));
        createCompetitionPanel.add(genderbox);
        createCompetitionPanel.add(createcompetition);

        //===============================================

        // Middle Panel for Adding Competitors
        JPanel competitorPanel = new JPanel();
        competitorPanel.setLayout(new BoxLayout(competitorPanel, BoxLayout.Y_AXIS));
        competitorPanel.setBorder(BorderFactory.createTitledBorder("Add Competitors"));

        competitorNameField = new JTextField();
        competitorAgeField = new JTextField();
        competitorMaxSpeedField = new JTextField();
        competitorAccelerationField = new JTextField();

        competitorPanel.add(new JLabel("Competitor Name:"));
        competitorPanel.add(competitorNameField);
        competitorPanel.add(new JLabel("Age:"));
        competitorPanel.add(competitorAgeField);
        competitorPanel.add(new JLabel("Max Speed:"));
        competitorPanel.add(competitorMaxSpeedField);
        competitorPanel.add(new JLabel("Acceleration:"));
        competitorPanel.add(competitorAccelerationField);
        addCompetitorButton = new JButton("Add Competitor");
        competitorPanel.add(addCompetitorButton);

        //===============================================

        // Start Competition Panel
        JPanel startPanel = new JPanel();
        startPanel.setLayout(new BoxLayout(startPanel, BoxLayout.Y_AXIS));
        startPanel.setBorder(BorderFactory.createTitledBorder("Start Competition"));

        startCompetitionButton = new JButton("Start Competition");
        startPanel.add(startCompetitionButton);

        // Info Panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Show Info"));

        showInfoButton = new JButton("Show Info");
        infoPanel.add(showInfoButton);

        // Adding to Right Panel
        rightPanel.add(configPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Spacer
        rightPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
        rightPanel.add(createCompetitionPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Spacer
        rightPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
        rightPanel.add(competitorPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Spacer
        rightPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
        rightPanel.add(startPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Spacer
        rightPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
        rightPanel.add(infoPanel);

        //===============================================



        // Add panels to main panel
        mainPanel.add(rightPanel, BorderLayout.EAST);
        mainPanel.add(LeftPanel, BorderLayout.CENTER);

        // Add main panel to frame
        add(mainPanel);

        // Action Listeners
        buildArenaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildArena();

            }
        });

        createcompetition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCompetition();
            }
        });

        addCompetitorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addCompetitor();
            }
        });

        startCompetitionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                competitionStarted = true;
                competitionFinished = false;
                for (Competitor competitor : comp.getActiveCompetitors()) {
                    if (competitor instanceof Runnable) {
                        new Thread((Runnable) competitor).start();
                        try {
                            Thread.sleep(100); // Brief delay between thread starts
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                }

                Timer timer = new Timer(30, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!competitionFinished) {
                            startCompetition();
                            updateCompetitorPositions();
                        } else {
                            ((Timer) e.getSource()).stop();
                        }
                    }
                });
                timer.start();
            }
        });


        showInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInfo();
            }
        });
    }

    private void createCompetition() {
        String competitionType = (String) competitionTypeComboBox.getSelectedItem();
        int maxCompetitors;
        String discipline = (String) disciplinebox.getSelectedItem();
        String leagueCategory = (String) leaguebox.getSelectedItem();
        String genderCategory = (String) genderbox.getSelectedItem();
        // conv
        Discipline conv_discipline= Discipline.valueOf(discipline);
        League conv_league =League.valueOf(leagueCategory);
        Gender conv_gender= Gender.valueOf(genderCategory);
        Compgender = conv_gender;

        try {
            maxCompetitors = Integer.parseInt(maxCompetitiorsnumber.getText());
            comp = new WinterCompetition(arena, maxCompetitors, conv_discipline, conv_league, conv_gender);

            JOptionPane.showMessageDialog(this, "Competition created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid max competitors number: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    public void buildArena() {
        String weatherCondition = (String) weatherConditionComboBox.getSelectedItem();
        String snowSurface = (String) snowsurfacebox.getSelectedItem();
        int arenaLength = 0;
        WeatherCondition conv_weather= WeatherCondition.valueOf(weatherCondition);
        SnowSurface conv_snow=SnowSurface.valueOf(snowSurface);

        try {
            arenaLength = Integer.parseInt(arenaLengthField.getText().split(" ")[0]);
            if (arenaLength < 700 || arenaLength > 900) {
                throw new NumberFormatException("Arena length must be between 700 and 900.");
            }
            arena = new WinterArena(arenaLength, conv_snow, conv_weather);
            JOptionPane.showMessageDialog(this, "Arena built successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            AddImage(weatherCondition);  // קריאה לפונקציה להוספת תמונה עם השם של תנאי מזג האוויר
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid arena length: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void AddImage(String arena_name) {
        String image_path = "src/resources/" + arena_name + ".jpg";
        ImageIcon icon = new ImageIcon(image_path);

        // קביעת גודל הפאנל המרכזי אחרי התחשבות בגודל הפאנל הימני
        int panelWidth = this.getWidth() - rightPanel.getWidth();
        int panelHeight = this.getHeight();

        Image image = icon.getImage().getScaledInstance(panelWidth, panelHeight, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(image);

        JLabel imageLabel = new JLabel(scaledIcon);

        LeftPanel.removeAll(); // הסרת כל הפאנלים הקיימים
        LeftPanel.setLayout(new BorderLayout());
        LeftPanel.add(imageLabel, BorderLayout.CENTER);

        LeftPanel.revalidate(); // רענון הפאנל
        LeftPanel.repaint(); // ציור מחדש של הפאנל
    }

    private void addCompetitor() {
        String name = competitorNameField.getText();
        double age, maxSpeed, acceleration;
        String discipline = (String) disciplinebox.getSelectedItem();
        String leagueCategory = (String) leaguebox.getSelectedItem();
        Discipline conv_discipline = Discipline.valueOf(discipline);
        League conv_league = League.valueOf(leagueCategory);
        try {
            age = Double.parseDouble(competitorAgeField.getText());
            maxSpeed = Double.parseDouble(competitorMaxSpeedField.getText());
            acceleration = Double.parseDouble(competitorAccelerationField.getText());

            if (Objects.equals(competitionTypeComboBox.getSelectedItem(), "Ski")) {
                competitor_ski = new Skier(conv_discipline, conv_league, name, age, Compgender, maxSpeed, acceleration);
                if (comp != null && comp.isValidCompetitor(competitor_ski)) {
                    comp.addCompetitor(competitor_ski);
                }
            } else if (Objects.equals(competitionTypeComboBox.getSelectedItem(), "Snowboard")) {
                competitor_snow = new Snowboarder(conv_discipline, conv_league, name, age, Compgender, maxSpeed, acceleration);
                if (comp != null && comp.isValidCompetitor(competitor_snow)) {
                    comp.addCompetitor(competitor_snow);
                }
            }

            String competitorImagePath;
            if (Objects.equals(competitionTypeComboBox.getSelectedItem(), "Ski")) {
                competitorImagePath = comp.getGender() == Gender.MALE ? "src/resources/SkiMale.png" : "src/resources/SkiFemale.png";
            } else if (Objects.equals(competitionTypeComboBox.getSelectedItem(), "Snowboard")) {
                competitorImagePath = comp.getGender() == Gender.MALE ? "src/resources/SnowboardMale.png" : "src/resources/SnowboardFemale.png";
            } else {
                throw new IllegalArgumentException("Unsupported competition type");
            }

            ImageIcon competitorIcon = new ImageIcon(competitorImagePath);
            Image image = competitorIcon.getImage();
            Image scaledImage = image.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            competitorIcon = new ImageIcon(scaledImage);

            if (competitorIcon.getImageLoadStatus() != MediaTracker.COMPLETE) {
                System.err.println("Failed to load image: " + competitorImagePath);
                return;
            }

            JLabel competitorLabel = new JLabel(competitorIcon);
            int xPosition = (comp.getActiveCompetitors().size() - 1) * 60;
            int yPosition = 10;
            competitorLabel.setBounds(xPosition, yPosition, 50, 50);
            LeftPanel.add(competitorLabel);
            LeftPanel.setComponentZOrder(competitorLabel, 0);
            LeftPanel.repaint();
            //LeftPanel.setLayout(null);

            if (Objects.equals(competitionTypeComboBox.getSelectedItem(), "Ski")) {
                competitorXPositions.put(competitor_ski, xPosition);
            } else if (Objects.equals(competitionTypeComboBox.getSelectedItem(), "Snowboard")) {
                competitorXPositions.put(competitor_snow, xPosition);
            }

            JOptionPane.showMessageDialog(this, "Competitor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid competitor details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Competitor does not fit to competition! Please choose another competitor.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void startCompetition () {
        ArrayList<Competitor> compTabel = new ArrayList<>(comp.getActiveCompetitors());//לבדוק
        comp.playTurn();
        comp.printWinners();
    }

    private void showInfo() {
        JFrame infoFrame = new JFrame("Competitors Information");
        infoFrame.setSize(600, 400);
        infoFrame.setLocationRelativeTo(this); // מיקום מסך המידע יחסית לחלון הראשי

        // יצירת מודל לטבלה עם כותרות עמודות
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Name");
        tableModel.addColumn("Speed");
        tableModel.addColumn("Max Speed");
        tableModel.addColumn("Location");
        tableModel.addColumn("Finished");

        // יצירת מערך נתונים
        java.util.List<Competitor> allCompetitors = new ArrayList<>(comp.getFinishedCompetitors());
        allCompetitors.addAll(comp.getActiveCompetitors());

        for (Competitor competitor : allCompetitors) {
            String name = competitor.getName();
            double speed = competitor.getSpeed();
            double maxSpeed = competitor.getMaxSpeed();
            Double location = Math.min(competitor.getLocation().get_x(),arena.getLength());
            String finished = competitor.hasFinished() ? "Yes" : "No";

            tableModel.addRow(new Object[]{name, speed, maxSpeed, location, finished});
        }

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        infoFrame.add(scrollPane);
        infoFrame.setVisible(true);
    }

    private void startTimer() {
        timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateCompetitorPositions();
            }
        });
        timer.start();
    }

    private void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }

    private void updateCompetitorPositions() {
        boolean allCompetitorsReachedBottom = true;
        int finishLine = LeftPanel.getHeight() - 50;

        java.util.List<Competitor> allCompetitors = new ArrayList<>(comp.getActiveCompetitors());
        allCompetitors.addAll(comp.getFinishedCompetitors());

        for (Competitor competitor : allCompetitors) {
            if (competitor instanceof WinterSportsman sportsman) {
                JLabel competitorLabel = getLabelForSportsman(sportsman);
                if (competitorLabel == null) continue;

                int xPosition = competitorXPositions.get(sportsman);
                double locationX = Math.min(sportsman.getLocation().get_x(), arena.getLength());
                double relativePosition = locationX / arena.getLength();
                int yPosition = (int) (relativePosition * finishLine);

                if (locationX >= arena.getLength() || sportsman.hasFinished()) {
                    yPosition = finishLine;
                    sportsman.setFinished(true);
                    System.out.println("Competitor " + sportsman.getName() + " finished at x: " + xPosition);
                } else {
                    allCompetitorsReachedBottom = false;
                    // בדיקה אם השחקן לא זז
                    if (locationX == 0) {
                        System.out.println("Warning: " + sportsman.getName() + " is not moving!");
                    }
                }

                competitorLabel.setBounds(xPosition, yPosition, 50, 50);
                System.out.println(sportsman.getName() + " - locationX: " + locationX + ", yPosition: " + yPosition);
            }
        }

        LeftPanel.revalidate();
        LeftPanel.repaint();

        if (allCompetitorsReachedBottom) {
            competitionFinished = true;
            competitionStarted = false;
            startCompetitionButton.setEnabled(true);
            JOptionPane.showMessageDialog(this, "The competition has ended!", "Information", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("All competitors reached the bottom. Competition finished.");
        }
    }


    private JLabel getLabelForSportsman(WinterSportsman sportsman) {
        for (Component component : LeftPanel.getComponents()) {
            if (component instanceof JLabel label) {
                if (label.getX()==competitorXPositions.get(sportsman)) {
                    return label;
                }
            }
        }
        return null;
    }

    public static void main (String[]args){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new competition().setVisible(true);
            }
        });
    }

}
